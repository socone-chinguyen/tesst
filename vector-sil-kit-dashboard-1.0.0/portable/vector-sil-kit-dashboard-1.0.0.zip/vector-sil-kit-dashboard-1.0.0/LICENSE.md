Vector Free Software License
============================
Copyright © Vector Informatik GmbH, Ingersheimer Strasse 24, 70499 Stuttgart, 
Germany (“Vector”). 
All rights reserved.
This software is provided under the terms of the Vector Free Software License which 
can be found at
https://cdn.vector.com/cms/content/corporate/terms-and-conditions/Vector_Terms_of_Use_for_Free_Software.pdf
By using this software you agree to the terms of that license.